﻿using System;
using System.Data.Entity;
using System.Data.Entity.Validation;

namespace Banking.Ef.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        public Banking_SystemContext Context { get; private set; }

        public UnitOfWork(DbContext context)
        {
            Context = (Banking_SystemContext)context;
        }

        public void MarkAsModified<T>(T item) where T : class
        {
            Context.Entry(item).State = EntityState.Modified;
        }

        public void MarkAsDeleted<T>(T item) where T : class
        {
            Context.Entry(item).State = EntityState.Deleted;
        }


        public void SaveChanges()
        {
            try
            {
                Context.SaveChanges();
            }
            catch (DbEntityValidationException ex)
            {
                throw ex;
            }
        }

        public void Dispose()
        {
            if (Context != null)
            {
                Context.Dispose();
                Context = null;
            }

            GC.SuppressFinalize(this);
        }
    }
}

