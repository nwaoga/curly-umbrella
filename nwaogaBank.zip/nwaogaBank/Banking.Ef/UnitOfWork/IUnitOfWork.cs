﻿using System;

namespace Banking.Ef.UnitOfWork
{
    public interface IUnitOfWork : IDisposable
    {
        Banking_SystemContext Context { get; }
        void SaveChanges();
        void MarkAsModified<T>(T item) where T : class;
        void MarkAsDeleted<T>(T item) where T : class;
    }
}