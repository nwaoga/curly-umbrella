﻿CREATE TABLE [dbo].[TEST] (
    [name]    NVARCHAR (30) NOT NULL,
    [picture] IMAGE         NOT NULL,
    [pic1]    IMAGE         NOT NULL
);

