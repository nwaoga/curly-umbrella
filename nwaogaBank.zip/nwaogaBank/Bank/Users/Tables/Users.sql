﻿CREATE TABLE [Users].[Users] (
    [userID]     INT            IDENTITY (2000, 1) NOT NULL,
    [userName]   NVARCHAR (15)  NOT NULL,
    [userPwd]    NVARCHAR (15)  NOT NULL,
    [pwdAttempt] INT            NOT NULL,
    [lock]       BIT            NULL,
    [userType]   VARCHAR (15)   NOT NULL,
    [errorMsg]   NVARCHAR (150) NOT NULL,
    [empNumber]  INT            NOT NULL,
    PRIMARY KEY CLUSTERED ([userID] ASC),
    CONSTRAINT [FK_users_empNumber] FOREIGN KEY ([empNumber]) REFERENCES [HumanResources].[Employees] ([emplNumber]) ON DELETE CASCADE
);

