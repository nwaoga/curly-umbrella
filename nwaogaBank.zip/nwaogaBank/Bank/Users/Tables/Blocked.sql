﻿CREATE TABLE [Users].[Blocked] (
    [userID] INT            NOT NULL,
    [active] BIT            NOT NULL,
    [reason] NVARCHAR (250) NOT NULL
);

