﻿CREATE TABLE [Users].[Recovery] (
    [userID]        INT           NOT NULL,
    [securityQst]   NVARCHAR (30) NOT NULL,
    [securityAnswr] NVARCHAR (30) NOT NULL
);

