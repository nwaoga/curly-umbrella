﻿CREATE TABLE [Users].[Type] (
    [usertypeID]  INT            IDENTITY (9000, 1) NOT NULL,
    [userType]    NVARCHAR (30)  NOT NULL,
    [Description] NVARCHAR (250) NOT NULL,
    PRIMARY KEY CLUSTERED ([usertypeID] ASC)
);

