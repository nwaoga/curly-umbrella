﻿CREATE TABLE [Users].[Allowance] (
    [usertypeID] INT NOT NULL
);

