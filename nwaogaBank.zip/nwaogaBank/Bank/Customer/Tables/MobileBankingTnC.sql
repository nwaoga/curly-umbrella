﻿CREATE TABLE [Customer].[MobileBankingTnC] (
    [accNmrMobBank] INT   NOT NULL,
    [Accepted]      BIT   NOT NULL,
    [date]          DATE  NOT NULL,
    [Signature]     IMAGE NULL,
    [ThumbPrint]    IMAGE NULL
);

