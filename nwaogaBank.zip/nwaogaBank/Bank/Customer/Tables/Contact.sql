﻿CREATE TABLE [Customer].[Contact] (
    [CustIDConact] INT           NOT NULL,
    [cellNumber]   NVARCHAR (10) NOT NULL,
    [email]        NVARCHAR (25) NULL,
    [address1]     NVARCHAR (40) NOT NULL,
    [address2]     NVARCHAR (40) NOT NULL,
    CONSTRAINT [FK_customerContact_CustomerID] FOREIGN KEY ([CustIDConact]) REFERENCES [Customer].[Customers] ([CustomerID]) ON DELETE CASCADE
);

