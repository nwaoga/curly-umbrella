﻿CREATE TABLE [Customer].[ThumbPrints] (
    [CustIDThumb] INT   NOT NULL,
    [ThumbPrint]  IMAGE NULL,
    CONSTRAINT [FK_ThumbPrints_CustomerID] FOREIGN KEY ([CustIDThumb]) REFERENCES [Customer].[Customers] ([CustomerID]) ON DELETE CASCADE
);

