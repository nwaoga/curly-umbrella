﻿CREATE TABLE [Customer].[RemoteBanking] (
    [RemoteBankID]  INT  IDENTITY (5000, 1) NOT NULL,
    [accNmrRemote]  INT  NOT NULL,
    [EmpNumber]     INT  NOT NULL,
    [AccessPin]     INT  NOT NULL,
    [dateActivated] DATE NOT NULL,
    PRIMARY KEY CLUSTERED ([RemoteBankID] ASC)
);

