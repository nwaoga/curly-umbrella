﻿CREATE TABLE [Customer].[Transactions] (
    [transID]         INT           IDENTITY (1000, 1) NOT NULL,
    [accNmbTrans]     INT           NOT NULL,
    [postingDate]     DATETIME      NOT NULL,
    [transDate]       DATETIME      NOT NULL,
    [tranDescription] NVARCHAR (50) NOT NULL,
    [fundsIn]         MONEY         NOT NULL,
    [fundsOut]        MONEY         NOT NULL,
    [available]       MONEY         NOT NULL,
    [balance]         MONEY         NOT NULL,
    PRIMARY KEY CLUSTERED ([transID] ASC),
    CONSTRAINT [FK_custTransactions_accNmbTrans] FOREIGN KEY ([accNmbTrans]) REFERENCES [Customer].[Account] ([accNumber]) ON DELETE CASCADE
);

