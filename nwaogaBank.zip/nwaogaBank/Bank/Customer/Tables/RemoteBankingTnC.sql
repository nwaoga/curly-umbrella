﻿CREATE TABLE [Customer].[RemoteBankingTnC] (
    [RemoteBankID] INT   NOT NULL,
    [Accepted]     BIT   NOT NULL,
    [Signature]    IMAGE NULL,
    [ThumbPrint]   IMAGE NULL
);

