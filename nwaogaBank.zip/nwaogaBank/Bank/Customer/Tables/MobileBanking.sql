﻿CREATE TABLE [Customer].[MobileBanking] (
    [accNmrMobBank] INT  NOT NULL,
    [EmpNumber]     INT  NOT NULL,
    [AccessPin]     INT  NOT NULL,
    [dateActivated] DATE NOT NULL,
    [dateModified]  DATE NOT NULL,
    PRIMARY KEY CLUSTERED ([accNmrMobBank] ASC),
    CONSTRAINT [FK_mobileBanking_accNumber] FOREIGN KEY ([accNmrMobBank]) REFERENCES [Customer].[Account] ([accNumber]) ON DELETE CASCADE
);

