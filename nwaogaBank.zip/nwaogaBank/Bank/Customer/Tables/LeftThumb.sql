﻿CREATE TABLE [Customer].[LeftThumb] (
    [CustIDLThumb] INT   NOT NULL,
    [Thumb1]       IMAGE NOT NULL,
    [Thumb2]       IMAGE NOT NULL,
    [Thumb3]       IMAGE NOT NULL,
    [Thumb4]       IMAGE NOT NULL,
    [Thumb5]       IMAGE NOT NULL,
    CONSTRAINT [FK_LeftThumb_CustomerID] FOREIGN KEY ([CustIDLThumb]) REFERENCES [Customer].[Customers] ([CustomerID]) ON DELETE CASCADE
);

