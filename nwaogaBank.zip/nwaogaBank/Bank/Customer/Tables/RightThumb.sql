﻿CREATE TABLE [Customer].[RightThumb] (
    [CustIDRThumb] INT   NOT NULL,
    [Thumb1]       IMAGE NOT NULL,
    [Thumb2]       IMAGE NOT NULL,
    [Thumb3]       IMAGE NOT NULL,
    [Thumb4]       IMAGE NOT NULL,
    [Thumb5]       IMAGE NOT NULL,
    CONSTRAINT [FK_RightThumb_CustomerID] FOREIGN KEY ([CustIDRThumb]) REFERENCES [Customer].[Customers] ([CustomerID]) ON DELETE CASCADE
);

