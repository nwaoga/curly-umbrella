﻿CREATE TABLE [Customer].[AccountTnC] (
    [CustIDAccTnC] INT   NOT NULL,
    [Accepted]     BIT   NOT NULL,
    [Signature]    IMAGE NULL,
    [ThumbPrint]   IMAGE NULL,
    CONSTRAINT [FK_AccountTnC_CustomerID] FOREIGN KEY ([CustIDAccTnC]) REFERENCES [Customer].[Customers] ([CustomerID]) ON DELETE CASCADE
);

