﻿CREATE TABLE [Customer].[Account] (
    [accNumber]  INT          IDENTITY (1000000000, 1) NOT NULL,
    [CustIDAcc]  INT          NOT NULL,
    [accType]    VARCHAR (15) NOT NULL,
    [pin]        INT          NOT NULL,
    [pinAtempt]  INT          NOT NULL,
    [available]  MONEY        NOT NULL,
    [balance]    MONEY        NOT NULL,
    [accState]   VARCHAR (10) NOT NULL,
    [dateOpened] DATETIME     NOT NULL,
    [expires]    DATE         NOT NULL,
    PRIMARY KEY CLUSTERED ([accNumber] ASC),
    CONSTRAINT [FK_customertAccount_CustomerID] FOREIGN KEY ([CustIDAcc]) REFERENCES [Customer].[Customers] ([CustomerID]) ON DELETE CASCADE
);

