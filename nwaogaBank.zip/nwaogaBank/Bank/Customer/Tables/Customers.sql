﻿CREATE TABLE [Customer].[Customers] (
    [CustomerID]     INT           IDENTITY (2000000000, 1) NOT NULL,
    [firstName]      VARCHAR (15)  NOT NULL,
    [lastName]       VARCHAR (15)  NULL,
    [surname]        VARCHAR (15)  NOT NULL,
    [initials]       VARCHAR (10)  NOT NULL,
    [title]          VARCHAR (5)   NOT NULL,
    [accountHolder]  VARCHAR (30)  NOT NULL,
    [DOB]            DATE          NOT NULL,
    [identityNumber] NVARCHAR (13) NOT NULL,
    [gender]         VARCHAR (6)   NOT NULL,
    PRIMARY KEY CLUSTERED ([CustomerID] ASC)
);

