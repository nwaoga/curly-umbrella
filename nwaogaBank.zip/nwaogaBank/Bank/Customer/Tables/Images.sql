﻿CREATE TABLE [Customer].[Images] (
    [CustIDImages] INT   NOT NULL,
    [picture]      IMAGE NOT NULL,
    [idCopy]       IMAGE NOT NULL,
    [Residence]    IMAGE NOT NULL,
    [SuretyIDcopy] IMAGE NULL,
    [ConsernForm]  IMAGE NULL,
    [dateCreated]  DATE  NOT NULL,
    [DateModified] DATE  NOT NULL,
    CONSTRAINT [FK_images_CustomerID] FOREIGN KEY ([CustIDImages]) REFERENCES [Customer].[Customers] ([CustomerID]) ON DELETE CASCADE
);

