﻿CREATE TABLE [HumanResources].[Employees] (
    [emplNumber]     INT           IDENTITY (12140000, 1) NOT NULL,
    [firstname]      VARCHAR (15)  NOT NULL,
    [surname]        VARCHAR (15)  NOT NULL,
    [lastname]       VARCHAR (15)  NULL,
    [DOB]            DATE          NOT NULL,
    [identitynumber] NVARCHAR (13) NOT NULL,
    [gender]         VARCHAR (6)   NOT NULL,
    [position]       VARCHAR (30)  NOT NULL,
    [picture]        IMAGE         NULL,
    PRIMARY KEY CLUSTERED ([emplNumber] ASC)
);

