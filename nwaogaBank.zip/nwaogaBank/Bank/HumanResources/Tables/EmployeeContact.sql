﻿CREATE TABLE [HumanResources].[EmployeeContact] (
    [empNumber]  INT           NOT NULL,
    [cellnumber] NVARCHAR (10) NOT NULL,
    [email]      NVARCHAR (25) NOT NULL,
    [address1]   NVARCHAR (40) NOT NULL,
    [address2]   NVARCHAR (40) NOT NULL,
    CONSTRAINT [FK_empContact_empNumber] FOREIGN KEY ([empNumber]) REFERENCES [HumanResources].[Employees] ([emplNumber]) ON DELETE CASCADE
);

