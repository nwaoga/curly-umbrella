﻿CREATE SCHEMA [Account]
    AUTHORIZATION [dbo];

