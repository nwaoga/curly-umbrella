﻿CREATE SCHEMA [HumanResources]
    AUTHORIZATION [dbo];

