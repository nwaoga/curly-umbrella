﻿CREATE TABLE [Account].[Freezing] (
    [accNmbState] INT            NOT NULL,
    [reason]      NVARCHAR (200) NULL,
    [DateFreeze]  DATE           NOT NULL,
    CONSTRAINT [FK_State_accNmbState] FOREIGN KEY ([accNmbState]) REFERENCES [Customer].[Account] ([accNumber]) ON DELETE CASCADE
);

