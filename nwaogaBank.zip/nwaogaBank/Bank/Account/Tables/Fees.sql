﻿CREATE TABLE [Account].[Fees] (
    [feeID]  INT           IDENTITY (200, 1) NOT NULL,
    [fee]    NVARCHAR (35) NOT NULL,
    [amount] MONEY         NOT NULL,
    PRIMARY KEY CLUSTERED ([feeID] ASC)
);

