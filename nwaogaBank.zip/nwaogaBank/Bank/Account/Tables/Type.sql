﻿CREATE TABLE [Account].[Type] (
    [AccTypeID]   INT           IDENTITY (2000, 1) NOT NULL,
    [AccountType] NVARCHAR (30) NOT NULL,
    [Description] TEXT          NOT NULL,
    [OpeningBal]  MONEY         NOT NULL,
    [MinimumBal]  MONEY         NOT NULL,
    PRIMARY KEY CLUSTERED ([AccTypeID] ASC)
);

