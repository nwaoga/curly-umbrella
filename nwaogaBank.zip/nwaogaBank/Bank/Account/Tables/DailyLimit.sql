﻿CREATE TABLE [Account].[DailyLimit] (
    [accNmbDaily] INT           NOT NULL,
    [amount]      MONEY         NOT NULL,
    [TempAmount]  SMALLMONEY    NULL,
    [period]      NVARCHAR (10) NOT NULL,
    [From]        DATE          NULL,
    [To]          DATE          NULL,
    PRIMARY KEY CLUSTERED ([accNmbDaily] ASC),
    CONSTRAINT [FK_DailyLimit_accNmbDaily] FOREIGN KEY ([accNmbDaily]) REFERENCES [Customer].[Account] ([accNumber]) ON DELETE CASCADE
);

