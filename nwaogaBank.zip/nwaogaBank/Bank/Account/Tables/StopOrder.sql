﻿CREATE TABLE [Account].[StopOrder] (
    [accNmr]          INT          NOT NULL,
    [accNmbStopOrder] INT          NOT NULL,
    [accountHolder]   VARCHAR (20) NOT NULL,
    [amount]          MONEY        NOT NULL,
    [transactionDate] DATE         NOT NULL,
    [dateAdded]       DATE         NOT NULL
);

